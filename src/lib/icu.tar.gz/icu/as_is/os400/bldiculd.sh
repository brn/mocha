#!/bin/sh
#  /* Copyright (C) 2011 IBM Corporation and Others. All Rights Reserved */
icc -o iculd iculd.c
